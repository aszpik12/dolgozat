class Gep:

    def __init__(self, sor):


        daraboltSor=sor.split("!")
        self.id=daraboltSor[0]
        self.hely=daraboltSor[1]
        self.tipus=daraboltSor[2]
        self.ipcim=daraboltSor[3]

    def __str__(self):
        return "Id: {}, hely: {}, tipus: {}, ipcim: {}".format(self.id, self.hely, self.tipus, self.ipcim)