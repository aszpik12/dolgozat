import random
from random import randint

def negativak_szama():
    index = 0
    negativ = 0
    oszthatotiz = 0
    while index < len(lista):
        if lista[index]%10==0:
            oszthatotiz+=1
        if lista[index]<0:
            negativ+=1
        index+=1
    return negativ

def konzolra_ir():
    print("\nII/D, E")
    print("\tTízzel osztható számok száma: ", end="")
    print(negativak_szama())

def fajl_ir():
    KiFajl = open("eredmenyek.txt","w",encoding="utf-8")
    print("II/F", file=KiFajl)
    print("\tTízzel osztható számok száma: ", end="", file=KiFajl)
    print(negativak_szama(),file=KiFajl)

lista = []
def masodik():
    index = 0
    while index < 15:
        randomszam = random.randint(-90, 500)
        lista.append(randomszam)
        index += 1

    print("II/A, B, C")
    print("\t{}".format(lista[0]), end="")
    index = 1
    while index < 15:
        print("*{}".format(lista[index]), end="")
        index += 1

    konzolra_ir()
    fajl_ir()
