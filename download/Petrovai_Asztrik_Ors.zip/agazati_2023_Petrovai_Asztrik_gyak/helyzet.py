import jatekos
def harmadik():
    epulet=[]

    def beolvas():
        beFajl=open("gep.txt","r",encoding="utf-8")
        beFajl.readline()
        adatok=beFajl.readlines()
        index = 0
        while index < len(adatok):
            sorom = adatok[index].strip()
            gepem = jatekos.Gep(sorom)
            epulet.append(gepem)
            index+=1
        beFajl.close()

    def kiir():
        index = 0
        while index < len(epulet):
            print(epulet[index])
            index+=1

    def gepDB():
        print("\nIII/A, B:")
        print("\tA gépek száma: {}.".format(len(epulet)))

    def atlag():
        pass

    def legkisebb():
        pass

    beolvas()
    kiir()
    gepDB()