import minosites
import sorozat
import helyzet

#minosites.elso()
#sorozat.masodik()
helyzet.harmadik()