def elso():
    print("I/A, B")
    muzeumnev = input("\tMúzeum neve: ")
    latogatonev = input("\tLátogató neve: ")
    ertek = int(input("\tÉrtékelés (1-20): "))

    print("I/C")

    if ertek <= 20 and ertek >= 1:
        print("\tKöszönjük az értékelést!")
    elif ertek <= 0:
        print("\tAz értékelés nem lehet negatív!")
    else:
        print("\t20 pont feletti értékelés nem elfogadható!")
