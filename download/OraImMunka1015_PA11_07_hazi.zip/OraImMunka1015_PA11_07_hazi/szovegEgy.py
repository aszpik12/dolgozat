def elso():
    print("1.	Kérj be tetszőleges szöveget, majd írasd ki a hosszát.")
    szoveg = input("Kérem adjon meg egy szöveget!")
    hossz = len(szoveg)
    print("A szöveg hossza: "+str(hossz)+".")

def masodik():
    print("2.	Kérj be tetszőleges szöveget, majd írasd ki úgy, hogy  minden karaktere egymás alatt legyen.")
    szoveg = input("Kérem adjon meg egy szöveget!")
    hossz = len(szoveg)
    # 1. változat
    index = 0
    while index < hossz:
        print(szoveg[index])
        index += 1

    #2.változat
    for index in range(0, hossz, 1):
        print(szoveg[index])

def harmadik():
    print("3.	Kérj be tetszőleges szöveget, majd mindek karakterét cseréld nagybetűsre.")
    szoveg = input("Kérem adjon meg egy szöveget!")
    # szovegKis=szoveg.lower() #kisbetűsít
    # print(szovegKis)
    szovegNagy = szoveg.upper() #nagybetűsít
    print(szovegNagy)

def negyedik():
    print("4.	Kérj be tetszőleges szöveget, majd írasd ki visszafelé.")

    szoveg=input("Kérem adjon meg egy szöveget!")
    hossz = len(szoveg)
    index = hossz-1
    while index >= 0:
        print(szoveg[index], end="")
        index -= 1

def otodik():
    print("5.	Írjon programot, mely megszámolja, hogy az inputként érkező mondatban hány darab ”a” betű van!")
    szoveg = input("Kérem adjon meg egy szöveget!")
    db=0
    hossz = len(szoveg)
    index = hossz - 1
    while index >= 0:
        if szoveg[index]=="a":
            db +=1
        index -= 1
    print("A szövegben előforduló 'a' betűk száma: "+str(db)+".")