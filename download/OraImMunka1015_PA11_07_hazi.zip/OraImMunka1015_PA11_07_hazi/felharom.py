import random


def fel3a():
    elemszam=int(input("Kérem adja mer az adatok darabszámát!:"))
    while elemszam <=0:
        elemszam = int(input("Kérem adja mer az adatok darabszámát!:"))

    lista1=[]
    db=0
    while db<elemszam:
        szam=random.randint(20,30)
        lista1.append(szam)
        db +=1

    for index in range (0,db,1):
        print(str(lista1[index])+" ", end="")
