import random


def a():
    print("3.	A program  kérjen be a konzolról egy valós számot! Ha ez a szám 0 és 360 közé esik, akkor legyen egy szög mértéke (pl. 60 fok), egyébként a program adjon hibaüzenetet! Ha lehet, a program írja ki a szög mértéke alapján a szög típusát (pl.: 60 -> hegyesszög)! (http://www.altsuli.hu/matf/keretszogtip.html)a.	véletlen számmal ugyanez" )

    max=360
    min=0
    szam = random.random()*((max-min+1)+min)
    #alakítsuk át, hoyg 2 tizedes jegyen jelenítse meg a tört számot
    szam=round(szam,2)

    print(str(szam)+" -> ", end="")
    if (szam <= 360) and (szam >= 0):
        if szam == 0:
            print("nullszög")
        elif (szam > 0) and (szam < 90):
            print("hegyesszög")
        elif szam == 90:
            print("derékszög")
        elif (szam > 90) and (szam < 180):
            print("tompaszög")
        elif szam == 180:
            print("egyenesszög")
        elif (szam > 180) and (szam < 360):
            print("homorúszög")
        elif szam == 360:
            print("teljesszög")
    else:
        print("HIBA: nem megfelelő fok érték!")
