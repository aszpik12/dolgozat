import random


def a():
    print("1.	A program olvasson be a konzolról egy egész számot! A program döntse el, hogy a megadott szám páros vagy páratlan, és írja ki az eredményt a konzolra!a.	Ugyanezt valósítsd meg véletlen számmal is!")
    szam=random.randint(-1000,1000)
    # print("A szám: "+str(szam))
    if szam % 2 == 0:
        print("A szám páros.")
    else:
        print("A szám páratlan.")