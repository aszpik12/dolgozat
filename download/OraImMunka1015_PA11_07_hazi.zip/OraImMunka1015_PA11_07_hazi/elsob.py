import random
import math


def b():
    print("1.	A program olvasson be a konzolról egy egész számot! A program döntse el, hogy a megadott szám páros vagy páratlan, és írja ki az eredményt a konzolra!a.	Ugyanezt valósítsd meg véletlen számmal is!b.	Csak páros számot fogadj el, és add meg a négyzetét!")
    szam = random.randint(-1000, 1000)
    # print("A szám: "+str(szam))

    while not(szam % 2 == 0):
        szam = random.randint(-1000, 1000)
        # print("A szám: " + str(szam))
    print("A "+str(szam)+" négyzete: "+str(int(math.pow(szam, 2))))
