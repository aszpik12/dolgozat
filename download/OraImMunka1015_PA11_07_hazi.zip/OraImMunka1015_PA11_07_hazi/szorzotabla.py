def szorzas():

    for szam in range (1,11,1):
        print("    {:>4d}".format(szam), end="")

    print("")
    for szam in range(1,11,1):
        print(str(szam))
        for szam2 in range(1,11,1):
            szorzat=szam*szam2
            print("    {:>4d}".format(szorzat), end="")
        print("")