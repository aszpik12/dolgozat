import random


def fel2c():

    lista1 = []
    lista2 = []
    ertek = 0
    while ertek<=30:
        lista1.append(ertek)
        ertek+=2

    ertek = 39
    while ertek>=21:
        lista1.append(ertek)
        ertek-=2


    index = 0
    while index < len(lista1):
        print(str(lista1[index])+"", end=" ")
        if index%5==4:
            print("")
        index += 1


    print("")
    index = 0
    while index < len(lista2):
        print(str(lista2[index]) + "", end=" ")
        if index % 5 == 4:
            print("")
        index += 1

    hossz1 = len(lista1)
    hossz2 = len(lista2)
    hosszOssz = hossz1+hossz2


    print("")
    index = 0
    while index < hosszOssz:
        if index<=len(lista1)-1:
            print(str(lista1[index]) + "", end=" ")
        else:
            print(str(lista2[index-len(lista1)]) + "", end=" ")
        if index % 5 == 4:
            print("")
        index += 1