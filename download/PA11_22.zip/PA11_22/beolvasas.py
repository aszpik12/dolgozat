def elso():
    szam = []
    with open("szam.txt", "r", encoding="utf-8") as InputFile:
        for n in InputFile:
            szam.append(int(n.strip()))
    return szam