import beolvasas

def min():
    szam = beolvasas.elso()
    min = 0
    for i in range(1, len(szam)):
        if szam[min] > szam[i]:
            min = i

    print("max értéke: " + str(szam[min]))