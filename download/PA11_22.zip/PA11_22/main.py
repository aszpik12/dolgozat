import max
import min

max.max()
min.min()