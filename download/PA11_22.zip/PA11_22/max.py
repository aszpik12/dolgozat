import beolvasas

def max():
    szam = beolvasas.elso()
    max = 0
    for i in range(1, len(szam)):
        if szam[max] < szam[i]:
            max = i

    print("max értéke: " + str(szam[max]))