
print("adjon megy egy számot!:");
i = int(input());

if (i<10):
    print("A megadott szám alatti egész szám:", i-1)
    print("A megadott szám feletti egész szám:", i+1);
