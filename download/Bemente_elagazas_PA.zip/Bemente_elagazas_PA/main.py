import pozitiv
import k_n_ertek
import szazalek
import osztajzat