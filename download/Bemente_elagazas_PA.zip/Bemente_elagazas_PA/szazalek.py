
print("adjon meg egy számot 0-100 között!:")
szam2 = int(input());

if (0<=szam2<=100):
    if szam2<=59:
        print(szam2, "% elégtelen")
    elif(szam2<=69):
        print(szam2, "% elégséges")
    elif(szam2<=79):
        print(szam2, "% közepes")
    elif(szam2<=89):
        print(szam2, "% jó")
    else:
        print(szam2, "% jeles")
else:
    print("Hiba! érvénytelen százalék!");
    print(" ")
