szam3 = int(input());

if (1<=szam3<=5):
    if szam3==1:
        print(szam3, "=elégtelen")
    elif(szam3==2):
        print(szam3, "=elégséges")
    elif(szam3==3):
        print(szam3, "=közepes")
    elif(szam3==4):
        print(szam3, "=jó")
    else:
        print(szam3, "=jeles")
else:
    print("Hiba! érvénytelen osztályzat!");