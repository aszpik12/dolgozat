print("Ez a program eldönti, hogy pozitív számot adott-e meg!:");
szam = int(input());

if (szam>0) :
    print(szam, "egy pozitív szám!");
