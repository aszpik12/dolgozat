import random
import math

def alap():
    print("1.A program olvasson be a konzolról egy egész számot! A program döntse el, hogy a megadott szám páros vagy páratlan, és írja ki az eredményt a konzolra!")
    szam=int(input("Kérem adjon meg egy egész számot!: "))
    if szam % 2 == 0:
        print("a szám páros")
    else:
        print("a szám páratlan")

def felegy():
    szam = random.randint(-10, 10)
    print("a szám: "+str(szam))
    if szam % 2 == 0:
        print("a szám páros")
    else:
        print("a szám páratlan")

def felket():
    d=0
    szam = random.randint(-100000, 100000)
    #print("a szám: "+str(szam))
    while not (szam%2==0):
        d+=1
        szam = random.randint(-10, 10)
    print(str(szam)+" négyzete "+str(int(math.pow(szam,2))))
    print("ez "+str(d)+" próbába került")
