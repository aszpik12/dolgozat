import elsofel
import masodfel
import harmadikfel
import negyedikfel
import otodikfel
import szovegegy

#elsofel.alap()
#elsofel.felegy()
#elsofel.felket()

#masodfel.alap()
#masodfel.felegy()
#masodfel.masodfel()

#harmadikfel.alap()
#harmadikfel.elsofel()

#negyedikfel.elsofel()

#otodikfel.elsofel()

#szovegegy.elso()
#szovegegy.masodik()
#szovegegy.harmadik()
#szovegegy.negyedik()
szovegegy.otodik()