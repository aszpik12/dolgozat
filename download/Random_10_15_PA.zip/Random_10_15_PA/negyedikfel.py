import math


def elsofel():
    szam = int(input("Kérek egy negatív egész számot!: "))
    while not szam < 0:
        print("rossz szám")
        szam = int(input("Kérek egy negatív egész számot!: "))
    print(str(szam) + " abszolút értéke: " + str(int(abs(szam))))