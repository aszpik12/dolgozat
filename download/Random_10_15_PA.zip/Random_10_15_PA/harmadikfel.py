import random


def alap():
    szam = int(input("Kérek egy szög méretét: "))
    if szam<=360 and szam>=0:
        if szam==0:
            print("nullszög")
        elif szam<90:
            print("hegyesszög")
        elif szam==90:
            print("derékszög")
        elif szam<180:
            print("tompaszög")
        elif szam==180:
            print("egyenesszög")
        elif szam<360:
            print("homorúszög")
        else:
            print("teljesszög")
    else:
        print("HIBA! helytelen szám!")

def elsofel():

    max = 360
    min = 0
    szam = random.random()*(max-min+1)+min

    print(str(round(szam, 2))+" -> ", end="")
    #if szam<=360 and szam>=0:

    if szam==0:
            print("nullszög")
    elif szam<90:
            print("hegyesszög")
    elif szam==90:
            print("derékszög")
    elif szam<180:
            print("tompaszög")
    elif szam==180:
            print("egyenesszög")
    elif szam<360:
            print("homorúszög")
    else:
            print("teljesszög")
  #  else:
  #      print("HIBA! helytelen szám!")