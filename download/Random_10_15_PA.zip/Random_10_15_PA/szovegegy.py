def elso():
    szoveg=input("kérem adjon meg egy szöveget!:")
    hossz=len(szoveg)
    print("a szöveg hossza", hossz)

def masodik():
    szoveg = input("kérem adjon meg egy szöveget!:")
    hossz = len(szoveg)
    index=0
    while index<hossz:
        print(szoveg[index])
        index += 1

    for index in range(0,hossz,1):
        print(szoveg[index])

def harmadik():
    szoveg = input("kérem adjon meg egy szöveget!:")
    hossz = len(szoveg)
    #szoveg = szoveg.lower()
    #print(szoveg)
    szoveg = szoveg.upper()
    print(szoveg)

def negyedik():
    szoveg = input("kérem adjon meg egy szöveget!:")
    hossz = len(szoveg)
    index=hossz-1
    while index >= 0:
        print(szoveg[index], end="")
        index-=1

def otodik():
    szoveg = input("kérem adjon meg egy szöveget!:")
    hossz = len(szoveg)
    db=0
    index = hossz - 1
    while index >= 0:
        if szoveg[index]  == "a":
            db += 1
        index -= 1
    print("A szövegben előfordul 'a' betűk száma: "+str(db)+".")
