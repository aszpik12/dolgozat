import math


def elsofel():
    szam = int(input("Kérek egy kétjegyű hárommal osztható számot!: "))
    while not (szam % 3 == 0 and szam < 100 and szam > 9):
        print("hiba")
        szam = int(input("Kérek egy kétjegyű hárommal osztható számot!: "))

    print(str(szam)+" négyzete: " + str(int(math.pow(szam, 2))))