def pelda1():
    for i in range(5):
        print(i)

def pelda2():
    for i in range(6,9):
        print(i)

def pelda3():
    for i in range(6,19,3):
        print(i)

def pelda4():
    for i in range(78,58,-3):
        print(i)

def pelda5():
    for i in range(13):
        print(i, end=" ")




