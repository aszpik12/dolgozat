def pelda1():
    n= 5
    m= int(input("kérek egy számot: "))
    while n > m:
        n -= 1
    print("n = ", n)


def pelda2():
    n = 5
    m = int(input("kérek egy számot: "))
    while n > m:
        n -= 1
        print("n = ", n)

def pelda3():
    n = 5
    m = int(input("kérek egy számot: "))
    while n < m:
        n -= 1
        print("n = ", n)

