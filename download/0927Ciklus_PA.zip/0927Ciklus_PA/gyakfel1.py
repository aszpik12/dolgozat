def pelda1():
    for i in range(-6):
        print(i)

def pelda2():
    for i in range(16, 6):
        print(i)

def pelda3():
    for i in range(16, 6, -2):
        print(i)

def fel1():
    for i in range(21):
        print(i)

def fel2():
    for i in range(20, 56 , 2):
        print(i)

def fel3():
     for i in range(77, -77, -4):
         print(i)

def fel4():
    szam1= int(input("adjon meg egy számot:"))
    szam2= int(input("adjon meg egy számot:"))
    if szam1< szam2:
        for i in range(szam1, szam2+1, 1):
            print(i, end=" ")
    else:
        for i in range(szam2, szam1+1, 1):
            print(i, end=" ")

def fel5():
    szam1= int(input("adjon meg egy számot:"))
    szam2= int(input("adjon meg egy számot:"))

    for i in range(0, szam1*szam2+1, 1):
        print(i, end=" ")

def fel6():

    szam1 = int(input("adjon meg egy számot:"))
    szam2 = int(input("adjon meg egy számot:"))
    szam3 = int(szam1*szam2+1)
    kezdet = int(0)
    print("Ez a for ciklus!")
    for i in range(0, szam1 * szam2 + 1, 1):
        print(i, end=" ")
    print("\nEz a while ciklus!")
    while(kezdet < szam3):
        print(kezdet, end=" ")
        kezdet = kezdet+1

def fel7():
    kezdet = int(1)

    while (kezdet<6):
        print(kezdet, end=",")
        kezdet = kezdet + 1
    print(kezdet+1)




