import mintapelda1
import munkapeldak2
import gyakfel1

#mintapelda1.pelda1()
#mintapelda1.pelda2()
#mintapelda1.pelda3()

#munkapeldak2.pelda1()
#munkapeldak2.pelda2()
#munkapeldak2.pelda3()
#munkapeldak2.pelda4()
#munkapeldak2.pelda5()

#gyakfel1.pelda1()
#gyakfel1.pelda2()
#gyakfel1.pelda3()
#gyakfel1.fel1()
#gyakfel1.fel2()
#gyakfel1.fel3()
#gyakfel1.fel4()
#gyakfel1.fel5()
#gyakfel1.fel6()
gyakfel1.fel7()